package com.shenawy.tv

import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

private val Ink = Color(0xFF0C1118)
private val Panel = Color(0xFF17212D)
private val Gold = Color(0xFFFFC94A)
private val Muted = Color(0xFFAAB7C4)

data class MediaEntry(
    val title: String,
    val category: String,
    val description: String,
    val streamUrl: String = "",
    val isLive: Boolean = false,
    val symbol: String = "▶"
)

// Demonstration catalogue only. Replace these entries with content you are licensed to distribute.
private val sampleCatalogue = listOf(
    MediaEntry("ليلة القاهرة", "أفلام", "فيلم تجريبي — أضف رابطًا تملك حق بثه.", symbol = "🎬"),
    MediaEntry("حكايات البيت", "مسلسلات", "مسلسل تجريبي — أضف المواسم والحلقات المرخصة.", symbol = "📺"),
    MediaEntry("قناة الأخبار", "قنوات مباشرة", "قناة تجريبية — أضف رابط HLS مرخصًا.", symbol = "🔴", isLive = true),
    MediaEntry("قناة العائلة", "قنوات مباشرة", "قناة تجريبية — أضف رابط HLS مرخصًا.", symbol = "📡", isLive = true),
    MediaEntry("مغامرة جديدة", "أفلام", "محتوى توضيحي إلى أن تربط كتالوجك الحقيقي.", symbol = "🍿"),
    MediaEntry("حكاية كل يوم", "مسلسلات", "محتوى توضيحي إلى أن تربط كتالوجك الحقيقي.", symbol = "🎭")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent { ShenawyTheme { ShenawyApp() } }
    }
}

@Composable
private fun ShenawyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = Ink, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

@Composable
private fun ShenawyApp() {
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedItem by remember { mutableStateOf<MediaEntry?>(null) }
    var searchText by remember { mutableStateOf("") }
    var searchOpen by remember { mutableStateOf(false) }
    val tabs = listOf("الرئيسية", "أفلام", "مسلسلات", "مباشر")
    val filtered = sampleCatalogue.filter {
        (selectedTab == "الرئيسية" ||
            (selectedTab == "مباشر" && it.isLive) ||
            it.category == selectedTab) &&
            (it.title.contains(searchText, ignoreCase = true) || it.description.contains(searchText, ignoreCase = true))
    }

    Scaffold(
        containerColor = Ink,
        topBar = {
            Column(Modifier.background(Ink)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Shenawy TV", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("أفلام • مسلسلات • بث مباشر", color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { searchOpen = !searchOpen; searchText = "" }) {
                        Icon(Icons.Default.Search, contentDescription = "بحث", tint = Color.White)
                    }
                }
                if (searchOpen) {
                    OutlinedTextField(
                        value = searchText, onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        placeholder = { Text("ابحث عن فيلم أو مسلسل أو قناة") },
                        singleLine = true
                    )
                }
                ScrollableTabRow(
                    selectedTabIndex = tabs.indexOf(selectedTab).coerceAtLeast(0),
                    containerColor = Ink, contentColor = Gold, edgePadding = 12.dp,
                    divider = {}
                ) {
                    tabs.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; selectedItem = null },
                            text = { Text(tab, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                listOf(
                    Triple("الرئيسية", Icons.Default.Home, "الرئيسية"),
                    Triple("بحث", Icons.Default.Search, "بحث"),
                    Triple("المفضلة", Icons.Default.FavoriteBorder, "المفضلة"),
                    Triple("حسابي", Icons.Default.Person, "حسابي")
                ).forEach { (label, icon, value) ->
                    NavigationBarItem(
                        selected = selectedTab == value,
                        onClick = {
                            if (value == "بحث") { searchOpen = true; selectedTab = "الرئيسية" }
                            else if (value == "المفضلة" || value == "حسابي") {
                                selectedTab = value
                            } else selectedTab = value
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Gold, selectedTextColor = Gold,
                            indicatorColor = Color(0xFF3A3323),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        if (selectedItem != null) {
            MediaDetails(
                item = selectedItem!!,
                modifier = Modifier.padding(padding),
                onBack = { selectedItem = null }
            )
        } else if (selectedTab == "المفضلة" || selectedTab == "حسابي") {
            PlaceholderScreen(
                title = if (selectedTab == "المفضلة") "قائمتك المفضلة" else "حسابك",
                text = if (selectedTab == "المفضلة") "ميزة المفضلة جاهزة للربط بقاعدة بيانات المستخدمين." else "يمكن إضافة تسجيل الدخول والملفات الشخصية في المرحلة التالية.",
                modifier = Modifier.padding(padding)
            )
        } else {
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())
            ) {
                HeroBanner(onClick = { selectedItem = sampleCatalogue.first() })
                Text(
                    "اختار اللي نفسك تتفرج عليه",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 8.dp)
                )
                if (filtered.isEmpty()) {
                    Text("مفيش نتائج مطابقة.", color = Muted, modifier = Modifier.padding(20.dp))
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filtered) { item -> MediaCard(item) { selectedItem = item } }
                    }
                }
                Text(
                    "الأكثر مشاهدة",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 8.dp)
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(sampleCatalogue.reversed()) { item -> MediaCard(item) { selectedItem = item } }
                }
                AdBanner(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp))
                Text(
                    "يعرض Shenawy TV في هذه النسخة عناصر تجريبية فقط. أضف المحتوى الذي تملك ترخيص بثه.",
                    color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                )
            }
        }
    }
}

@Composable
private fun HeroBanner(onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)
            .height(190.dp)
            .background(
                Brush.linearGradient(listOf(Color(0xFF4A3520), Color(0xFF202B39), Color(0xFF101820))),
                RoundedCornerShape(22.dp)
            ).clickable { onClick() }.padding(20.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Text("عرض مميز", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("حكايتك تبدأ هنا", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("أفلام ومسلسلات وقنوات مباشرة", color = Color(0xFFE2E6EA), fontSize = 12.sp)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.background(Gold, RoundedCornerShape(10.dp)).padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Ink)
                Text("استكشف الآن", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
        Text("▶", fontSize = 56.sp, color = Color(0x66FFC94A), modifier = Modifier.align(Alignment.CenterEnd))
    }
}

@Composable
private fun MediaCard(item: MediaEntry, onClick: () -> Unit) {
    Column(Modifier.width(142.dp).clickable { onClick() }) {
        Box(
            Modifier.fillMaxWidth().height(164.dp)
                .background(
                    Brush.linearGradient(listOf(Color(0xFF374B5D), Color(0xFF202B36), Color(0xFF553F25))),
                    RoundedCornerShape(14.dp)
                )
        ) {
            Text(item.symbol, fontSize = 40.sp, modifier = Modifier.align(Alignment.Center))
            if (item.isLive) {
                Row(
                    Modifier.align(Alignment.TopStart).padding(7.dp)
                        .background(Color(0xFFE83E43), RoundedCornerShape(5.dp))
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text("● مباشر", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Icon(Icons.Default.PlayCircle, contentDescription = "تشغيل", tint = Gold,
                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).size(28.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
        Text(item.category, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MediaDetails(item: MediaEntry, modifier: Modifier = Modifier, onBack: () -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text("رجوع") }
        Box(
            Modifier.fillMaxWidth().height(220.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF4A3520), Panel)), RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) { Text(item.symbol, fontSize = 72.sp) }
        Spacer(Modifier.height(16.dp))
        Text(item.title, fontSize = 25.sp, fontWeight = FontWeight.Black, color = Gold)
        Text(item.category + if (item.isLive) " • بث مباشر" else " • محتوى", color = Muted)
        Spacer(Modifier.height(12.dp))
        Text(item.description, color = Color.White, lineHeight = 23.sp)
        Spacer(Modifier.height(18.dp))
        if (item.streamUrl.isBlank()) {
            Text(
                "لم يتم ربط مصدر تشغيل لهذا العنصر بعد. أضف رابط فيديو أو HLS مرخصًا في كتالوج الإدارة.",
                color = Muted, lineHeight = 22.sp
            )
        } else {
            Player(item.streamUrl)
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun Player(url: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply { this.player = player; layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 650) } },
        modifier = Modifier.fillMaxWidth().height(230.dp)
    )
}

@Composable
private fun AdBanner(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.height(58.dp),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                // Google's official test banner unit ID. Replace with your own AdMob unit before release.
                adUnitId = "ca-app-pub-3940256099942544/6300978111"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}

@Composable
private fun PlaceholderScreen(title: String, text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.LiveTv, contentDescription = null, tint = Gold, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(16.dp))
        Text(title, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(text, color = Muted, textAlign = TextAlign.Center, lineHeight = 24.sp)
    }
}
